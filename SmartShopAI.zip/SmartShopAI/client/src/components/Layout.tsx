import { useState } from "react";
import { Link } from "wouter";
import { Search, Menu, ShoppingCart, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import CartSidebar from "./CartSidebar";
import Chatbot from "./Chatbot";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center px-4">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="h-5 w-5" />
            </Button>
            <Link href="/">
              <a className="font-bold text-xl">SnapBuy</a>
            </Link>
          </div>

          {/* Search */}
          <div className="flex items-center space-x-4 ml-auto">
            <form className="hidden md:flex items-center" onSubmit={(e) => {
              e.preventDefault();
              window.location.href = `/category/${searchQuery}`;
            }}>
              <Input
                type="search"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-64"
              />
            </form>

            {/* Cart & Chat buttons */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsCartOpen(true)}
            >
              <ShoppingCart className="h-5 w-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsChatOpen(true)}
            >
              <MessageCircle className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </nav>

      {/* Main content */}
      <main className="container mx-auto px-4 py-8">
        {children}
      </main>

      {/* Cart Sidebar */}
      <CartSidebar open={isCartOpen} onClose={() => setIsCartOpen(false)} />

      {/* Chatbot */}
      <Chatbot open={isChatOpen} onClose={() => setIsChatOpen(false)} />
    </div>
  );
}
