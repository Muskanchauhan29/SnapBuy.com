import { useQuery } from "@tanstack/react-query";
import ProductGrid from "@/components/ProductGrid";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import type { Product, Category } from "@shared/schema";

export default function Home() {
  const { data: products = [] } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: recommendations = [] } = useQuery<Product[]>({
    queryKey: ["/api/recommendations"],
  });

  return (
    <div className="space-y-12">
      {/* Categories */}
      <section>
        <h2 className="text-2xl font-bold mb-6">Shop by Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {categories.map((category) => (
            <Link key={category.id} href={`/category/${category.name}`}>
              <a className="relative group overflow-hidden rounded-lg">
                <img
                  src={category.banner}
                  alt={category.name}
                  className="w-full h-40 object-cover transition-transform group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                  <h3 className="text-white font-bold text-xl">{category.name}</h3>
                </div>
              </a>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      {recommendations.length > 0 && (
        <section>
          <h2 className="text-2xl font-bold mb-6">Recommended for You</h2>
          <ProductGrid products={recommendations} />
        </section>
      )}

      {/* All Products */}
      <section>
        <h2 className="text-2xl font-bold mb-6">All Products</h2>
        <ProductGrid products={products} />
      </section>
    </div>
  );
}
