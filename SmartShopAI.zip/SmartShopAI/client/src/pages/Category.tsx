import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import ProductGrid from "@/components/ProductGrid";
import type { Product, Category } from "@shared/schema";

export default function CategoryPage() {
  const [, params] = useRoute("/category/:category");
  const category = params?.category || "";

  const { data: products = [] } = useQuery<Product[]>({
    queryKey: [`/api/products/category/${category}`],
  });

  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const categoryData = categories.find(
    (c) => c.name.toLowerCase() === category.toLowerCase()
  );

  return (
    <div className="space-y-8">
      {/* Category Banner */}
      {categoryData && (
        <div className="relative h-48 rounded-lg overflow-hidden">
          <img
            src={categoryData.banner}
            alt={categoryData.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
            <h1 className="text-white text-4xl font-bold">{categoryData.name}</h1>
          </div>
        </div>
      )}

      {/* Products */}
      <div>
        <h2 className="text-2xl font-bold mb-6">
          {products.length} Products Found
        </h2>
        <ProductGrid products={products} />
      </div>
    </div>
  );
}
