import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { useState } from "react";
import type { CartItem, Product } from "@shared/schema";

export default function Checkout() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [paymentMethod, setPaymentMethod] = useState<"card" | "cod">("card");

  const { data: cartItems = [] } = useQuery<CartItem[]>({
    queryKey: ["/api/cart"],
  });

  const { data: products = [] } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const total = cartItems.reduce((sum, item) => {
    const product = products.find((p) => p.id === item.productId);
    return sum + (product?.price || 0) * item.quantity;
  }, 0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // In a real app, you would process payment here for card payments
    toast({
      title: "Order placed!",
      description: paymentMethod === "card" 
        ? "Thank you for your purchase." 
        : "Your order will be delivered within 3-5 business days. Payment will be collected upon delivery.",
    });

    setLocation("/");
  };

  if (cartItems.length === 0) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold mb-4">Your cart is empty</h1>
        <Button onClick={() => setLocation("/")}>Continue Shopping</Button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-8">Checkout</h1>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Order Summary */}
        <div className="space-y-4">
          <h2 className="font-semibold text-lg">Order Summary</h2>
          {cartItems.map((item) => {
            const product = products.find((p) => p.id === item.productId);
            if (!product) return null;

            return (
              <div key={item.id} className="flex items-center space-x-4">
                <img
                  src={product.image}
                  alt={product.name}
                  className="h-16 w-16 object-cover rounded"
                />
                <div className="flex-1">
                  <h3 className="font-medium">{product.name}</h3>
                  <p className="text-sm text-muted-foreground">
                    {item.quantity} × ${product.price.toFixed(2)}
                  </p>
                </div>
                <p className="font-medium">
                  ${(product.price * item.quantity).toFixed(2)}
                </p>
              </div>
            );
          })}

          <div className="border-t pt-4">
            <div className="flex justify-between font-bold">
              <span>Total</span>
              <span>${total.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Checkout Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <h2 className="font-semibold text-lg">Shipping Information</h2>
            <Input placeholder="Full Name" required />
            <Input placeholder="Email" type="email" required />
            <Input placeholder="Phone Number" type="tel" required />
            <Input placeholder="Address" required />
            <Input placeholder="City" required />
            <div className="grid grid-cols-2 gap-4">
              <Input placeholder="State" required />
              <Input placeholder="ZIP Code" required />
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="font-semibold text-lg">Payment Method</h2>
            <RadioGroup 
              value={paymentMethod} 
              onValueChange={(value) => setPaymentMethod(value as "card" | "cod")}
              className="space-y-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="card" id="card" />
                <Label htmlFor="card">Credit/Debit Card</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="cod" id="cod" />
                <Label htmlFor="cod">Cash on Delivery</Label>
              </div>
            </RadioGroup>

            {paymentMethod === "card" && (
              <div className="space-y-4">
                <Input placeholder="Card Number" required={paymentMethod === "card"} />
                <div className="grid grid-cols-3 gap-4">
                  <Input placeholder="MM/YY" required={paymentMethod === "card"} />
                  <Input placeholder="CVC" required={paymentMethod === "card"} />
                </div>
              </div>
            )}
          </div>

          <Button type="submit" className="w-full">
            {paymentMethod === "card" ? "Pay Now" : "Place Order"}
          </Button>
        </form>
      </div>
    </div>
  );
}