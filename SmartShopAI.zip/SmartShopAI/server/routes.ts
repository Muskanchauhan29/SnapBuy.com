import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { generateChatResponse, getProductRecommendations } from "./openai";
import { insertCartItemSchema, insertChatMessageSchema } from "@shared/schema";

export function registerRoutes(app: Express) {
  // Products
  app.get("/api/products", async (req, res) => {
    const products = await storage.getProducts();
    res.json(products);
  });

  app.get("/api/products/:id", async (req, res) => {
    const product = await storage.getProduct(Number(req.params.id));
    if (!product) {
      res.status(404).json({ message: "Product not found" });
      return;
    }
    res.json(product);
  });

  app.get("/api/products/category/:category", async (req, res) => {
    const products = await storage.getProductsByCategory(req.params.category);
    res.json(products);
  });

  app.get("/api/products/search/:query", async (req, res) => {
    const products = await storage.searchProducts(req.params.query);
    res.json(products);
  });

  // Categories
  app.get("/api/categories", async (req, res) => {
    const categories = await storage.getCategories();
    res.json(categories);
  });

  // Cart
  app.get("/api/cart", async (req, res) => {
    const sessionId = req.sessionID;
    const items = await storage.getCartItems(sessionId);
    res.json(items);
  });

  app.post("/api/cart", async (req, res) => {
    try {
      const sessionId = req.sessionID;
      const data = insertCartItemSchema.parse({ ...req.body, sessionId });
      const item = await storage.addToCart(data);
      res.json(item);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/cart/:id", async (req, res) => {
    const { quantity } = req.body;
    const item = await storage.updateCartItem(Number(req.params.id), quantity);
    if (!item) {
      res.status(404).json({ message: "Cart item not found" });
      return;
    }
    res.json(item);
  });

  app.delete("/api/cart/:id", async (req, res) => {
    await storage.removeFromCart(Number(req.params.id));
    res.status(204).end();
  });

  // Chat
  app.get("/api/chat", async (req, res) => {
    const sessionId = req.sessionID;
    const messages = await storage.getChatMessages(sessionId);
    res.json(messages);
  });

  app.post("/api/chat", async (req, res) => {
    try {
      const sessionId = req.sessionID;
      const { message } = req.body;

      // Save user message
      const userMessage = await storage.addChatMessage({
        sessionId,
        message,
        fromUser: true,
        timestamp: new Date().toISOString(),
      });

      // Get chat history
      const messages = await storage.getChatMessages(sessionId);
      const history = messages.map(msg => ({
        role: msg.fromUser ? "user" as const : "assistant" as const,
        content: msg.message
      }));

      // Generate AI response
      const response = await generateChatResponse(message, history);

      // Save AI response
      const aiMessage = await storage.addChatMessage({
        sessionId,
        message: response,
        fromUser: false,
        timestamp: new Date().toISOString(),
      });

      res.json({ userMessage, aiMessage });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Recommendations
  app.get("/api/recommendations", async (req, res) => {
    const sessionId = req.sessionID;
    const products = await storage.getProducts();
    const cartItems = await storage.getCartItems(sessionId);

    try {
      // Get user's interests based on cart
      const cartProducts = cartItems.map(item => 
        products.find(p => p.id === item.productId)
      ).filter(Boolean);

      const userInterests = {
        categories: [...new Set(cartProducts.map(p => p?.category))],
        priceRange: cartProducts.length > 0 
          ? {
              min: Math.min(...cartProducts.map(p => p?.price || 0)),
              max: Math.max(...cartProducts.map(p => p?.price || 0))
            }
          : null
      };

      const userBehavior = `User has ${cartItems.length} items in cart. 
        Interested in categories: ${userInterests.categories.join(", ")}. 
        Price range: ${userInterests.priceRange 
          ? `$${userInterests.priceRange.min} - $${userInterests.priceRange.max}`
          : 'Not established'}`;

      // Try to get AI recommendations first
      const recommendedIds = await getProductRecommendations(products, userBehavior);

      // Get the actual product objects
      const recommendations = await Promise.all(
        recommendedIds.map(id => storage.getProduct(id))
      );

      res.json(recommendations.filter(Boolean));
    } catch (error) {
      console.error("Recommendation error:", error);
      // Fallback to basic recommendations if AI fails
      const fallbackRecommendations = products
        .filter(p => !cartItems.some(item => item.productId === p.id))
        .sort(() => Math.random() - 0.5)
        .slice(0, 5);

      res.json(fallbackRecommendations);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}