import {
  type Product,
  type Category,
  type CartItem,
  type ChatMessage,
  type InsertProduct,
  type InsertCategory,
  type InsertCartItem,
  type InsertChatMessage,
  products,
  categories,
  cartItems,
  chatMessages,
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductsByCategory(category: string): Promise<Product[]>;
  searchProducts(query: string): Promise<Product[]>;

  // Categories
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;

  // Cart
  getCartItems(sessionId: string): Promise<CartItem[]>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, quantity: number): Promise<CartItem | undefined>;
  removeFromCart(id: number): Promise<void>;

  // Chat
  getChatMessages(sessionId: string): Promise<ChatMessage[]>;
  addChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
}

export class DatabaseStorage implements IStorage {
  // Products
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return await db
      .select()
      .from(products)
      .where(eq(products.category, category));
  }

  async searchProducts(query: string): Promise<Product[]> {
    const lowercaseQuery = query.toLowerCase();
    const allProducts = await this.getProducts();
    return allProducts.filter(
      (p) =>
        p.name.toLowerCase().includes(lowercaseQuery) ||
        p.description.toLowerCase().includes(lowercaseQuery)
    );
  }

  // Categories
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  async getCategory(id: number): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category;
  }

  // Cart
  async getCartItems(sessionId: string): Promise<CartItem[]> {
    return await db
      .select()
      .from(cartItems)
      .where(eq(cartItems.sessionId, sessionId));
  }

  async addToCart(item: InsertCartItem): Promise<CartItem> {
    const [cartItem] = await db
      .insert(cartItems)
      .values(item)
      .returning();
    return cartItem;
  }

  async updateCartItem(id: number, quantity: number): Promise<CartItem | undefined> {
    const [updated] = await db
      .update(cartItems)
      .set({ quantity })
      .where(eq(cartItems.id, id))
      .returning();
    return updated;
  }

  async removeFromCart(id: number): Promise<void> {
    await db.delete(cartItems).where(eq(cartItems.id, id));
  }

  // Chat
  async getChatMessages(sessionId: string): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.sessionId, sessionId))
      .orderBy(chatMessages.timestamp);
  }

  async addChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [chatMessage] = await db
      .insert(chatMessages)
      .values(message)
      .returning();
    return chatMessage;
  }
}

// Initialize with sample data
async function initializeData() {
  const existingProducts = await db.select().from(products);
  if (existingProducts.length === 0) {
    // Sample categories
    const categoryData = [
      { name: "Electronics", banner: "https://images.unsplash.com/photo-1558770147-a0e2842c5ea1" },
      { name: "Fashion", banner: "https://images.unsplash.com/photo-1524871729950-c4e886edc1f9" },
      { name: "Home", banner: "https://images.unsplash.com/photo-1558770147-d2a384e1ad85" },
      { name: "Sports", banner: "https://images.unsplash.com/photo-1558770147-68c0607adb26" },
      { name: "Beauty", banner: "https://images.unsplash.com/photo-1621777106818-aa0303a2adc7" },
      { name: "Books", banner: "https://images.unsplash.com/photo-1598845210582-699090239180" },
    ];

    await db.insert(categories).values(categoryData);

    // Sample products
    const productData = [
      {
        name: "Premium Wireless Headphones",
        description: "Premium sound quality with active noise cancellation",
        price: 299.99,
        category: "Electronics",
        image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e",
        stock: 15,
      },
      {
        name: "4K Smart TV",
        description: "55-inch 4K Ultra HD Smart LED TV with HDR",
        price: 699.99,
        category: "Electronics",
        image: "https://images.unsplash.com/photo-1593784991095-a205069470b6",
        stock: 8,
      },
      {
        name: "Gaming Laptop",
        description: "High-performance gaming laptop with RGB keyboard",
        price: 1299.99,
        category: "Electronics",
        image: "https://images.unsplash.com/photo-1603302576837-37561b2e2302",
        stock: 5,
      },
      {
        name: "Smartphone",
        description: "Latest model with advanced camera system",
        price: 899.99,
        category: "Electronics",
        image: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab",
        stock: 20,
      },
      {
        name: "Designer Watch",
        description: "Elegant timepiece for any occasion",
        price: 199.99,
        category: "Fashion",
        image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30",
        stock: 10,
      },
      {
        name: "Leather Handbag",
        description: "Genuine leather bag with gold hardware",
        price: 159.99,
        category: "Fashion",
        image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa",
        stock: 12,
      },
      {
        name: "Running Shoes",
        description: "Comfortable athletic shoes with support",
        price: 89.99,
        category: "Fashion",
        image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff",
        stock: 25,
      },
      {
        name: "Sunglasses",
        description: "UV protection with classic design",
        price: 129.99,
        category: "Fashion",
        image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083",
        stock: 30,
      },
      {
        name: "Modern Coffee Table",
        description: "Sleek design with storage compartment",
        price: 249.99,
        category: "Home",
        image: "https://images.unsplash.com/photo-1533090481720-856c6e3c1fdc",
        stock: 6,
      },
      {
        name: "Smart Light Bulbs",
        description: "WiFi-enabled RGB light bulbs",
        price: 39.99,
        category: "Home",
        image: "https://images.unsplash.com/photo-1550525811-e5869dd03032",
        stock: 40,
      },
      {
        name: "Robot Vacuum",
        description: "Smart robot vacuum with mapping",
        price: 299.99,
        category: "Home",
        image: "https://images.unsplash.com/photo-1562254492-377a3ac576f4",
        stock: 10,
      },
      {
        name: "Throw Pillows Set",
        description: "Decorative pillows with modern patterns",
        price: 49.99,
        category: "Home",
        image: "https://images.unsplash.com/photo-1584100936595-c0654b55a2e2",
        stock: 15,
      },
      {
        name: "Yoga Mat",
        description: "Non-slip exercise mat with carrying strap",
        price: 29.99,
        category: "Sports",
        image: "https://images.unsplash.com/photo-1592432678016-e910b452f9a2",
        stock: 35,
      },
      {
        name: "Dumbbells Set",
        description: "Adjustable weight set with stand",
        price: 199.99,
        category: "Sports",
        image: "https://images.unsplash.com/photo-1586401100295-7a8096fd231a",
        stock: 8,
      },
      {
        name: "Tennis Racket",
        description: "Professional grade tennis racket",
        price: 159.99,
        category: "Sports",
        image: "https://images.unsplash.com/photo-1622279457486-62dcc4a431d6",
        stock: 12,
      },
      {
        name: "Basketball",
        description: "Official size indoor/outdoor basketball",
        price: 29.99,
        category: "Sports",
        image: "https://images.unsplash.com/photo-1519861531473-9200262188bf",
        stock: 20,
      },
      {
        name: "Skincare Set",
        description: "Complete daily skincare routine kit",
        price: 89.99,
        category: "Beauty",
        image: "https://images.unsplash.com/photo-1612817288484-6f916006741a",
        stock: 15,
      },
      {
        name: "Hair Dryer",
        description: "Professional salon-grade hair dryer",
        price: 129.99,
        category: "Beauty",
        image: "https://images.unsplash.com/photo-1522338242992-e1a54906a8da",
        stock: 10,
      },
      {
        name: "Makeup Palette",
        description: "Versatile eyeshadow palette with mirror",
        price: 49.99,
        category: "Beauty",
        image: "https://images.unsplash.com/photo-1512496015851-a90fb38ba796",
        stock: 25,
      },
      {
        name: "Face Serum",
        description: "Anti-aging vitamin C serum",
        price: 39.99,
        category: "Beauty",
        image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be",
        stock: 30,
      },
      {
        name: "Mystery Novel Collection",
        description: "Set of bestselling mystery novels",
        price: 49.99,
        category: "Books",
        image: "https://images.unsplash.com/photo-1512820790803-83ca734da794",
        stock: 20,
      },
      {
        name: "Cookbook",
        description: "International recipes with photos",
        price: 34.99,
        category: "Books",
        image: "https://images.unsplash.com/photo-1589998059171-988d887df646",
        stock: 15,
      },
      {
        name: "Self-Help Book",
        description: "Bestselling personal development guide",
        price: 19.99,
        category: "Books",
        image: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c",
        stock: 25,
      },
      {
        name: "Children's Book Set",
        description: "Illustrated story collection for kids",
        price: 29.99,
        category: "Books",
        image: "https://images.unsplash.com/photo-1512436991641-6745cdb1723f",
        stock: 18,
      },
    ];

    await db.insert(products).values(productData);
  }
}

export const storage = new DatabaseStorage();
initializeData().catch(console.error);