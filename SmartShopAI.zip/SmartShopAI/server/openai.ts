import OpenAI from "openai";
import type { Product } from "@shared/schema";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function generateChatResponse(
  message: string,
  sessionHistory: { role: "user" | "assistant"; content: string }[]
): Promise<string> {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return getDefaultChatResponse(message);
    }

    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: `You are a helpful e-commerce shopping assistant. Your role is to:
          - Help customers find products they're looking for
          - Make personalized product recommendations
          - Answer questions about product features and specifications
          - Assist with order and shipping related queries
          - Provide fashion and style advice when asked

          Keep responses friendly and concise. If asked about products, focus on items in these categories:
          - Electronics: headphones, TVs, laptops, smartphones
          - Fashion: watches, bags, shoes, sunglasses
          - Home: furniture, lighting, appliances
          - Sports: fitness equipment, gear
          - Beauty: skincare, haircare, makeup
          - Books: various genres and collections`,
        },
        ...sessionHistory,
        { role: "user", content: message },
      ],
      temperature: 0.7,
      max_tokens: 300,
    });

    return response.choices[0].message.content || getDefaultChatResponse(message);
  } catch (error) {
    console.error("OpenAI API error:", error);
    return getDefaultChatResponse(message);
  }
}

function getDefaultChatResponse(message: string): string {
  const lowercaseMessage = message.toLowerCase();

  // Basic keyword matching for common queries
  if (lowercaseMessage.includes("shipping") || lowercaseMessage.includes("delivery")) {
    return "We offer free shipping on orders over $50. Standard delivery takes 3-5 business days.";
  }

  if (lowercaseMessage.includes("return") || lowercaseMessage.includes("refund")) {
    return "We have a 30-day return policy for all unused items in original packaging.";
  }

  if (lowercaseMessage.includes("payment") || lowercaseMessage.includes("pay")) {
    return "We accept all major credit cards, PayPal, and Apple Pay.";
  }

  if (lowercaseMessage.includes("contact") || lowercaseMessage.includes("help")) {
    return "You can reach our customer service team at support@shopsmart.com or browse our product categories for assistance.";
  }

  return "I apologize, but I'm currently experiencing technical difficulties. You can browse our product categories or contact customer service for immediate assistance.";
}

export async function getProductRecommendations(
  products: Product[],
  userBehavior: string
): Promise<number[]> {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return getDefaultRecommendations(products);
    }

    const prompt = `Based on the following information:

    Available products: ${JSON.stringify(products.map(p => ({
      id: p.id,
      name: p.name,
      category: p.category,
      price: p.price,
      description: p.description
    })))}

    User behavior: "${userBehavior}"

    Recommend 5 products that would be most relevant for this user. Consider:
    - Products from similar categories they've shown interest in
    - Complementary items that go well with their cart items
    - Popular items in relevant categories
    - Price points similar to their current selections

    Return ONLY a JSON object containing an array of product IDs under the key 'recommendations'.
    Example response: {"recommendations": [1, 2, 3, 4, 5]}`;

    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7,
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.recommendations || getDefaultRecommendations(products);
  } catch (error) {
    console.error("OpenAI API error:", error);
    return getDefaultRecommendations(products);
  }
}

function getDefaultRecommendations(products: Product[]): number[] {
  // Get a mix of products from different categories
  const categorizedProducts = products.reduce((acc, product) => {
    if (!acc[product.category]) {
      acc[product.category] = [];
    }
    acc[product.category].push(product);
    return acc;
  }, {} as Record<string, Product[]>);

  const recommendations: number[] = [];

  // Try to get one product from each category
  Object.values(categorizedProducts).forEach(categoryProducts => {
    if (recommendations.length < 5) {
      const randomProduct = categoryProducts[Math.floor(Math.random() * categoryProducts.length)];
      if (randomProduct && !recommendations.includes(randomProduct.id)) {
        recommendations.push(randomProduct.id);
      }
    }
  });

  // Fill remaining slots with random products if needed
  while (recommendations.length < 5 && products.length > 0) {
    const randomProduct = products[Math.floor(Math.random() * products.length)];
    if (!recommendations.includes(randomProduct.id)) {
      recommendations.push(randomProduct.id);
    }
  }

  return recommendations;
}